var Calculator  = {};
Calculator.add= function(a,b)
{
	a = isNumber(a) ? parseFloat(a) : 0;
	b = isNumber(b) ? parseFloat(b) : 0;
	return (a+b);
};

function isNumber(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}